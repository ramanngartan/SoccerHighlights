package com.dirzaaulia.footballclips.util

const val SCOREBAT_BASE_URL = "https://www.scorebat.com/"
const val SCOREBAT_TOKEN =
    "MjExMDVfMTY1NjQ3NzQ1OF8wMjIwMDFlZThmZDdlMTVkNDI5YzhhZmRjOWZhNzkzODY0ODFkNTNm"

const val FOOTBALL_API_BASE_URL = "https://v3.football.api-sports.io/"
const val FOOTBALL_API_TOKEN = "51cb32c53f6de72429c67b2a04a9d982"