package com.dirzaaulia.footballclips.util

class NotFoundException : RuntimeException("Data not found")